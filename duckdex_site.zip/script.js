let data = [];

fetch('listings.json')
  .then(res => res.json())
  .then(json => {
    data = json;
    renderDirectory(data);
  });

function renderDirectory(list) {
  const container = document.getElementById('directory');
  container.innerHTML = '';
  list.forEach(app => {
    container.innerHTML += `
      <div class="bg-white p-4 rounded shadow">
        <div class="font-semibold text-lg">${app.name}</div>
        <p class="text-sm text-gray-600 mb-2">${app.description}</p>
        <a href="${app.telegram}" target="_blank" class="text-blue-600 text-sm font-medium">Play on Telegram</a>
      </div>`;
  });
}

document.getElementById('search').addEventListener('input', e => {
  const keyword = e.target.value.toLowerCase();
  const filtered = data.filter(app => app.name.toLowerCase().includes(keyword));
  renderDirectory(filtered);
});
